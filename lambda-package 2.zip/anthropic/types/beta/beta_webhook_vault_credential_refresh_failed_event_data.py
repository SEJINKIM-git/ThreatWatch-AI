# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal

from ..._models import BaseModel

__all__ = ["BetaWebhookVaultCredentialRefreshFailedEventData"]


class BetaWebhookVaultCredentialRefreshFailedEventData(BaseModel):
    id: str
    """ID of the vault credential that triggered the event."""

    organization_id: str

    type: Literal["vault_credential.refresh_failed"]

    vault_id: str
    """ID of the vault that owns this credential."""

    workspace_id: str

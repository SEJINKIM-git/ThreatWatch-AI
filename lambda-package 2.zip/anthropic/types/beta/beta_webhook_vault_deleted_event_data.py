# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal

from ..._models import BaseModel

__all__ = ["BetaWebhookVaultDeletedEventData"]


class BetaWebhookVaultDeletedEventData(BaseModel):
    id: str
    """ID of the vault that triggered the event."""

    organization_id: str

    type: Literal["vault.deleted"]

    workspace_id: str
